#ifndef SLIP_H
#define SLIP_H

void slip_parse_buf(char *buf, short length);

#endif
