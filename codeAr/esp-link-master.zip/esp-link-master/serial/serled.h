#ifndef SERLED_H
#define SERLED_H

void serledFlash(int duration);
void serledInit(void);
void makeGpio(uint8_t pin);

#endif
