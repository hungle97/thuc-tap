#ifndef CGITCP_H
#define CGITCP_H

#include "httpd.h"

int cgiTcp(HttpdConnData *connData);

#endif
